# New-Fashioned Storage

We found several malicious file-transfer activity on our Encrypted-FS. Could you figured it out?

MD5sum: `bc21bb7d5185c5af89d4674746363c02` (log.pcap)

Author: `Avilia#1337`
